(self.webpackChunkclient = self.webpackChunkclient || []).push([
    [6241], {
        28197: (t, e, i) => {
            "use strict";
            i.d(e, {
                c0: () => it,
                rv: () => nt
            });
            const n = {
                toVector: (t, e) => (void 0 === t && (t = e), Array.isArray(t) ? t : [t, t]),
                add: (t, e) => [t[0] + e[0], t[1] + e[1]],
                sub: (t, e) => [t[0] - e[0], t[1] - e[1]],
                addTo(t, e) {
                    t[0] += e[0], t[1] += e[1]
                },
                subTo(t, e) {
                    t[0] -= e[0], t[1] -= e[1]
                }
            };

            function s(t, e, i) {
                return 0 === e || Math.abs(e) === 1 / 0 ? Math.pow(t, 5 * i) : t * e * i / (e + i * t)
            }

            function o(t, e, i, n = .15) {
                return 0 === n ? function(t, e, i) {
                    return Math.max(e, Math.min(t, i))
                }(t, e, i) : t < e ? -s(e - t, i - e, n) + e : t > i ? +s(t - i, i - e, n) + i : t
            }

            function r(t) {
                var e = function(t, e) {
                    if ("object" !== typeof t || null === t) return t;
                    var i = t[Symbol.toPrimitive];
                    if (void 0 !== i) {
                        var n = i.call(t, e || "default");
                        if ("object" !== typeof n) return n;
                        throw new TypeError("@@toPrimitive must return a primitive value.")
                    }
                    return ("string" === e ? String : Number)(t)
                }(t, "string");
                return "symbol" === typeof e ? e : String(e)
            }

            function a(t, e, i) {
                return (e = r(e)) in t ? Object.defineProperty(t, e, {
                    value: i,
                    enumerable: !0,
                    configurable: !0,
                    writable: !0
                }) : t[e] = i, t
            }

            function c(t, e) {
                var i = Object.keys(t);
                if (Object.getOwnPropertySymbols) {
                    var n = Object.getOwnPropertySymbols(t);
                    e && (n = n.filter((function(e) {
                        return Object.getOwnPropertyDescriptor(t, e).enumerable
                    }))), i.push.apply(i, n)
                }
                return i
            }

            function h(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var i = null != arguments[e] ? arguments[e] : {};
                    e % 2 ? c(Object(i), !0).forEach((function(e) {
                        a(t, e, i[e])
                    })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(i)) : c(Object(i)).forEach((function(e) {
                        Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(i, e))
                    }))
                }
                return t
            }
            const u = {
                pointer: {
                    start: "down",
                    change: "move",
                    end: "up"
                },
                mouse: {
                    start: "down",
                    change: "move",
                    end: "up"
                },
                touch: {
                    start: "start",
                    change: "move",
                    end: "end"
                },
                gesture: {
                    start: "start",
                    change: "change",
                    end: "end"
                }
            };

            function l(t) {
                return t ? t[0].toUpperCase() + t.slice(1) : ""
            }
            const d = ["enter", "leave"];

            function p(t, e = "", i = !1) {
                const n = u[t],
                    s = n && n[e] || e;
                return "on" + l(t) + l(s) + (function(t = !1, e) {
                    return t && !d.includes(e)
                }(i, s) ? "Capture" : "")
            }
            const f = ["gotpointercapture", "lostpointercapture"];

            function v(t) {
                let e = t.substring(2).toLowerCase();
                const i = !!~e.indexOf("passive");
                i && (e = e.replace("passive", ""));
                const n = f.includes(e) ? "capturecapture" : "capture",
                    s = !!~e.indexOf(n);
                return s && (e = e.replace("capture", "")), {
                    device: e,
                    capture: s,
                    passive: i
                }
            }

            function m(t) {
                return "touches" in t
            }

            function g(t) {
                return m(t) ? "touch" : "pointerType" in t ? t.pointerType : "mouse"
            }

            function b(t) {
                return m(t) ? function(t) {
                    return "touchend" === t.type || "touchcancel" === t.type ? t.changedTouches : t.targetTouches
                }(t)[0] : t
            }

            function y(t) {
                return function(t) {
                    return Array.from(t.touches).filter(e => {
                        var i, n;
                        return e.target === t.currentTarget || (null === (i = t.currentTarget) || void 0 === i || null === (n = i.contains) || void 0 === n ? void 0 : n.call(i, e.target))
                    })
                }(t).map(t => t.identifier)
            }

            function _(t) {
                const e = b(t);
                return m(t) ? e.identifier : e.pointerId
            }

            function w(t) {
                const e = b(t);
                return [e.clientX, e.clientY]
            }

            function k(t) {
                let {
                    deltaX: e,
                    deltaY: i,
                    deltaMode: n
                } = t;
                return 1 === n ? (e *= 40, i *= 40) : 2 === n && (e *= 800, i *= 800), [e, i]
            }

            function S(t, ...e) {
                return "function" === typeof t ? t(...e) : t
            }

            function T() {}

            function x(...t) {
                return 0 === t.length ? T : 1 === t.length ? t[0] : function() {
                    let e;
                    for (const i of t) e = i.apply(this, arguments) || e;
                    return e
                }
            }

            function O(t, e) {
                return Object.assign({}, e, t || {})
            }
            class D {
                constructor(t, e, i) {
                    this.ctrl = t, this.args = e, this.key = i, this.state || (this.state = {}, this.computeValues([0, 0]), this.computeInitial(), this.init && this.init(), this.reset())
                }
                get state() {
                    return this.ctrl.state[this.key]
                }
                set state(t) {
                    this.ctrl.state[this.key] = t
                }
                get shared() {
                    return this.ctrl.state.shared
                }
                get eventStore() {
                    return this.ctrl.gestureEventStores[this.key]
                }
                get timeoutStore() {
                    return this.ctrl.gestureTimeoutStores[this.key]
                }
                get config() {
                    return this.ctrl.config[this.key]
                }
                get sharedConfig() {
                    return this.ctrl.config.shared
                }
                get handler() {
                    return this.ctrl.handlers[this.key]
                }
                reset() {
                    const {
                        state: t,
                        shared: e,
                        ingKey: i,
                        args: n
                    } = this;
                    e[i] = t._active = t.active = t._blocked = t._force = !1, t._step = [!1, !1], t.intentional = !1, t._movement = [0, 0], t._distance = [0, 0], t._direction = [0, 0], t._delta = [0, 0], t._bounds = [
                        [-1 / 0, 1 / 0],
                        [-1 / 0, 1 / 0]
                    ], t.args = n, t.axis = void 0, t.memo = void 0, t.elapsedTime = t.timeDelta = 0, t.direction = [0, 0], t.distance = [0, 0], t.overflow = [0, 0], t._movementBound = [!1, !1], t.velocity = [0, 0], t.movement = [0, 0], t.delta = [0, 0], t.timeStamp = 0
                }
                start(t) {
                    const e = this.state,
                        i = this.config;
                    e._active || (this.reset(), this.computeInitial(), e._active = !0, e.target = t.target, e.currentTarget = t.currentTarget, e.lastOffset = i.from ? S(i.from, e) : e.offset, e.offset = e.lastOffset, e.startTime = e.timeStamp = t.timeStamp)
                }
                computeValues(t) {
                    const e = this.state;
                    e._values = t, e.values = this.config.transform(t)
                }
                computeInitial() {
                    const t = this.state;
                    t._initial = t._values, t.initial = t.values
                }
                compute(t) {
                    const {
                        state: e,
                        config: i,
                        shared: s
                    } = this;
                    e.args = this.args;
                    let r = 0;
                    if (t && (e.event = t, i.preventDefault && t.cancelable && e.event.preventDefault(), e.type = t.type, s.touches = this.ctrl.pointerIds.size || this.ctrl.touchIds.size, s.locked = !!document.pointerLockElement, Object.assign(s, function(t) {
                            const e = {};
                            if ("buttons" in t && (e.buttons = t.buttons), "shiftKey" in t) {
                                const {
                                    shiftKey: i,
                                    altKey: n,
                                    metaKey: s,
                                    ctrlKey: o
                                } = t;
                                Object.assign(e, {
                                    shiftKey: i,
                                    altKey: n,
                                    metaKey: s,
                                    ctrlKey: o
                                })
                            }
                            return e
                        }(t)), s.down = s.pressed = s.buttons % 2 === 1 || s.touches > 0, r = t.timeStamp - e.timeStamp, e.timeStamp = t.timeStamp, e.elapsedTime = e.timeStamp - e.startTime), e._active) {
                        const t = e._delta.map(Math.abs);
                        n.addTo(e._distance, t)
                    }
                    this.axisIntent && this.axisIntent(t);
                    const [a, c] = e._movement, [h, u] = i.threshold, {
                        _step: l,
                        values: d
                    } = e;
                    if (i.hasCustomTransform ? (!1 === l[0] && (l[0] = Math.abs(a) >= h && d[0]), !1 === l[1] && (l[1] = Math.abs(c) >= u && d[1])) : (!1 === l[0] && (l[0] = Math.abs(a) >= h && Math.sign(a) * h), !1 === l[1] && (l[1] = Math.abs(c) >= u && Math.sign(c) * u)), e.intentional = !1 !== l[0] || !1 !== l[1], !e.intentional) return;
                    const p = [0, 0];
                    if (i.hasCustomTransform) {
                        const [t, e] = d;
                        p[0] = !1 !== l[0] ? t - l[0] : 0, p[1] = !1 !== l[1] ? e - l[1] : 0
                    } else p[0] = !1 !== l[0] ? a - l[0] : 0, p[1] = !1 !== l[1] ? c - l[1] : 0;
                    this.restrictToAxis && !e._blocked && this.restrictToAxis(p);
                    const f = e.offset,
                        v = e._active && !e._blocked || e.active;
                    v && (e.first = e._active && !e.active, e.last = !e._active && e.active, e.active = s[this.ingKey] = e._active, t && (e.first && ("bounds" in i && (e._bounds = S(i.bounds, e)), this.setup && this.setup()), e.movement = p, this.computeOffset()));
                    const [m, g] = e.offset, [
                        [b, y],
                        [_, w]
                    ] = e._bounds;
                    e.overflow = [m < b ? -1 : m > y ? 1 : 0, g < _ ? -1 : g > w ? 1 : 0], e._movementBound[0] = !!e.overflow[0] && (!1 === e._movementBound[0] ? e._movement[0] : e._movementBound[0]), e._movementBound[1] = !!e.overflow[1] && (!1 === e._movementBound[1] ? e._movement[1] : e._movementBound[1]);
                    const k = e._active && i.rubberband || [0, 0];
                    if (e.offset = function(t, [e, i], [n, s]) {
                            const [
                                [r, a],
                                [c, h]
                            ] = t;
                            return [o(e, r, a, n), o(i, c, h, s)]
                        }(e._bounds, e.offset, k), e.delta = n.sub(e.offset, f), this.computeMovement(), v && (!e.last || r > 32)) {
                        e.delta = n.sub(e.offset, f);
                        const t = e.delta.map(Math.abs);
                        n.addTo(e.distance, t), e.direction = e.delta.map(Math.sign), e._direction = e._delta.map(Math.sign), !e.first && r > 0 && (e.velocity = [t[0] / r, t[1] / r], e.timeDelta = r)
                    }
                }
                emit() {
                    const t = this.state,
                        e = this.shared,
                        i = this.config;
                    if (t._active || this.clean(), (t._blocked || !t.intentional) && !t._force && !i.triggerAllEvents) return;
                    const n = this.handler(h(h(h({}, e), t), {}, {
                        [this.aliasKey]: t.values
                    }));
                    void 0 !== n && (t.memo = n)
                }
                clean() {
                    this.eventStore.clean(), this.timeoutStore.clean()
                }
            }
            class A extends D {
                constructor(...t) {
                    super(...t), a(this, "aliasKey", "xy")
                }
                reset() {
                    super.reset(), this.state.axis = void 0
                }
                init() {
                    this.state.offset = [0, 0], this.state.lastOffset = [0, 0]
                }
                computeOffset() {
                    this.state.offset = n.add(this.state.lastOffset, this.state.movement)
                }
                computeMovement() {
                    this.state.movement = n.sub(this.state.offset, this.state.lastOffset)
                }
                axisIntent(t) {
                    const e = this.state,
                        i = this.config;
                    if (!e.axis && t) {
                        const n = "object" === typeof i.axisThreshold ? i.axisThreshold[g(t)] : i.axisThreshold;
                        e.axis = function([t, e], i) {
                            const n = Math.abs(t),
                                s = Math.abs(e);
                            return n > s && n > i ? "x" : s > n && s > i ? "y" : void 0
                        }(e._movement, n)
                    }
                    e._blocked = (i.lockDirection || !!i.axis) && !e.axis || !!i.axis && i.axis !== e.axis
                }
                restrictToAxis(t) {
                    if (this.config.axis || this.config.lockDirection) switch (this.state.axis) {
                        case "x":
                            t[1] = 0;
                            break;
                        case "y":
                            t[0] = 0
                    }
                }
            }
            const E = t => t,
                M = {
                    enabled: (t = !0) => t,
                    eventOptions: (t, e, i) => h(h({}, i.shared.eventOptions), t),
                    preventDefault: (t = !1) => t,
                    triggerAllEvents: (t = !1) => t,
                    rubberband(t = 0) {
                        switch (t) {
                            case !0:
                                return [.15, .15];
                            case !1:
                                return [0, 0];
                            default:
                                return n.toVector(t)
                        }
                    },
                    from: t => "function" === typeof t ? t : null != t ? n.toVector(t) : void 0,
                    transform(t, e, i) {
                        const n = t || i.shared.transform;
                        return this.hasCustomTransform = !!n, n || E
                    },
                    threshold: t => n.toVector(t, 0)
                };
            const P = h(h({}, M), {}, {
                    axis(t, e, {
                        axis: i
                    }) {
                        if (this.lockDirection = "lock" === i, !this.lockDirection) return i
                    },
                    axisThreshold: (t = 0) => t,
                    bounds(t = {}) {
                        if ("function" === typeof t) return e => P.bounds(t(e));
                        if ("current" in t) return () => t.current;
                        if ("function" === typeof HTMLElement && t instanceof HTMLElement) return t;
                        const {
                            left: e = -1 / 0,
                            right: i = 1 / 0,
                            top: n = -1 / 0,
                            bottom: s = 1 / 0
                        } = t;
                        return [
                            [e, i],
                            [n, s]
                        ]
                    }
                }),
                C = {
                    ArrowRight: (t, e = 1) => [t * e, 0],
                    ArrowLeft: (t, e = 1) => [-1 * t * e, 0],
                    ArrowUp: (t, e = 1) => [0, -1 * t * e],
                    ArrowDown: (t, e = 1) => [0, t * e]
                };
            const I = "undefined" !== typeof window && window.document && window.document.createElement;

            function K() {
                return I && "ontouchstart" in window || I && window.navigator.maxTouchPoints > 1
            }
            const j = {
                    isBrowser: I,
                    gesture: function() {
                        try {
                            return "constructor" in GestureEvent
                        } catch (t) {
                            return !1
                        }
                    }(),
                    touch: K(),
                    touchscreen: K(),
                    pointer: I && "onpointerdown" in window,
                    pointerLock: I && "exitPointerLock" in window.document
                },
                B = {
                    mouse: 0,
                    touch: 0,
                    pen: 8
                },
                L = h(h({}, P), {}, {
                    device(t, e, {
                        pointer: {
                            touch: i = !1,
                            lock: n = !1,
                            mouse: s = !1
                        } = {}
                    }) {
                        return this.pointerLock = n && j.pointerLock, j.touch && i ? "touch" : this.pointerLock ? "mouse" : j.pointer && !s ? "pointer" : j.touch ? "touch" : "mouse"
                    },
                    preventScrollAxis(t, e, {
                        preventScroll: i
                    }) {
                        if (this.preventScrollDelay = "number" === typeof i ? i : i || void 0 === i && t ? 250 : void 0, j.touchscreen && !1 !== i) return t || (void 0 !== i ? "y" : void 0)
                    },
                    pointerCapture(t, e, {
                        pointer: {
                            capture: i = !0,
                            buttons: n = 1,
                            keys: s = !0
                        } = {}
                    }) {
                        return this.pointerButtons = n, this.keys = s, !this.pointerLock && "pointer" === this.device && i
                    },
                    threshold(t, e, {
                        filterTaps: i = !1,
                        tapsThreshold: s = 3,
                        axis: o
                    }) {
                        const r = n.toVector(t, i ? s : o ? 1 : 0);
                        return this.filterTaps = i, this.tapsThreshold = s, r
                    },
                    swipe({
                        velocity: t = .5,
                        distance: e = 50,
                        duration: i = 250
                    } = {}) {
                        return {
                            velocity: this.transform(n.toVector(t)),
                            distance: this.transform(n.toVector(e)),
                            duration: i
                        }
                    },
                    delay(t = 0) {
                        switch (t) {
                            case !0:
                                return 180;
                            case !1:
                                return 0;
                            default:
                                return t
                        }
                    },
                    axisThreshold: t => t ? h(h({}, B), t) : B,
                    keyboardDisplacement: (t = 10) => t
                });

            function V(t) {
                const [e, i] = t.overflow, [n, s] = t._delta, [o, r] = t._direction;
                (e < 0 && n > 0 && o < 0 || e > 0 && n < 0 && o > 0) && (t._movement[0] = t._movementBound[0]), (i < 0 && s > 0 && r < 0 || i > 0 && s < 0 && r > 0) && (t._movement[1] = t._movementBound[1])
            }
            h(h({}, M), {}, {
                device(t, e, {
                    shared: i,
                    pointer: {
                        touch: n = !1
                    } = {}
                }) {
                    if (i.target && !j.touch && j.gesture) return "gesture";
                    if (j.touch && n) return "touch";
                    if (j.touchscreen) {
                        if (j.pointer) return "pointer";
                        if (j.touch) return "touch"
                    }
                },
                bounds(t, e, {
                    scaleBounds: i = {},
                    angleBounds: n = {}
                }) {
                    const s = t => {
                            const e = O(S(i, t), {
                                min: -1 / 0,
                                max: 1 / 0
                            });
                            return [e.min, e.max]
                        },
                        o = t => {
                            const e = O(S(n, t), {
                                min: -1 / 0,
                                max: 1 / 0
                            });
                            return [e.min, e.max]
                        };
                    return "function" !== typeof i && "function" !== typeof n ? [s(), o()] : t => [s(t), o(t)]
                },
                threshold(t, e, i) {
                    this.lockDirection = "lock" === i.axis;
                    return n.toVector(t, this.lockDirection ? [.1, 3] : 0)
                },
                modifierKey: t => void 0 === t ? "ctrlKey" : t,
                pinchOnWheel: (t = !0) => t
            });
            h(h({}, P), {}, {
                mouseOnly: (t = !0) => t
            });
            const U = P;
            h(h({}, P), {}, {
                mouseOnly: (t = !0) => t
            });
            const H = new Map,
                z = new Map;

            function R(t) {
                H.set(t.key, t.engine), z.set(t.key, t.resolver)
            }
            const X = {
                    key: "drag",
                    engine: class extends A {
                        constructor(...t) {
                            super(...t), a(this, "ingKey", "dragging")
                        }
                        reset() {
                            super.reset();
                            const t = this.state;
                            t._pointerId = void 0, t._pointerActive = !1, t._keyboardActive = !1, t._preventScroll = !1, t._delayed = !1, t.swipe = [0, 0], t.tap = !1, t.canceled = !1, t.cancel = this.cancel.bind(this)
                        }
                        setup() {
                            const t = this.state;
                            if (t._bounds instanceof HTMLElement) {
                                const e = t._bounds.getBoundingClientRect(),
                                    i = t.currentTarget.getBoundingClientRect(),
                                    n = {
                                        left: e.left - i.left + t.offset[0],
                                        right: e.right - i.right + t.offset[0],
                                        top: e.top - i.top + t.offset[1],
                                        bottom: e.bottom - i.bottom + t.offset[1]
                                    };
                                t._bounds = P.bounds(n)
                            }
                        }
                        cancel() {
                            const t = this.state;
                            t.canceled || (t.canceled = !0, t._active = !1, setTimeout(() => {
                                this.compute(), this.emit()
                            }, 0))
                        }
                        setActive() {
                            this.state._active = this.state._pointerActive || this.state._keyboardActive
                        }
                        clean() {
                            this.pointerClean(), this.state._pointerActive = !1, this.state._keyboardActive = !1, super.clean()
                        }
                        pointerDown(t) {
                            const e = this.config,
                                i = this.state;
                            if (null != t.buttons && (Array.isArray(e.pointerButtons) ? !e.pointerButtons.includes(t.buttons) : -1 !== e.pointerButtons && e.pointerButtons !== t.buttons)) return;
                            const n = this.ctrl.setEventIds(t);
                            e.pointerCapture && t.target.setPointerCapture(t.pointerId), n && n.size > 1 && i._pointerActive || (this.start(t), this.setupPointer(t), i._pointerId = _(t), i._pointerActive = !0, this.computeValues(w(t)), this.computeInitial(), e.preventScrollAxis && "mouse" !== g(t) ? (i._active = !1, this.setupScrollPrevention(t)) : e.delay > 0 ? (this.setupDelayTrigger(t), e.triggerAllEvents && (this.compute(t), this.emit())) : this.startPointerDrag(t))
                        }
                        startPointerDrag(t) {
                            const e = this.state;
                            e._active = !0, e._preventScroll = !0, e._delayed = !1, this.compute(t), this.emit()
                        }
                        pointerMove(t) {
                            const e = this.state,
                                i = this.config;
                            if (!e._pointerActive) return;
                            const s = _(t);
                            if (void 0 !== e._pointerId && s !== e._pointerId) return;
                            const o = w(t);
                            return document.pointerLockElement === t.target ? e._delta = [t.movementX, t.movementY] : (e._delta = n.sub(o, e._values), this.computeValues(o)), n.addTo(e._movement, e._delta), this.compute(t), e._delayed && e.intentional ? (this.timeoutStore.remove("dragDelay"), e.active = !1, void this.startPointerDrag(t)) : i.preventScrollAxis && !e._preventScroll ? e.axis ? e.axis === i.preventScrollAxis || "xy" === i.preventScrollAxis ? (e._active = !1, void this.clean()) : (this.timeoutStore.remove("startPointerDrag"), void this.startPointerDrag(t)) : void 0 : void this.emit()
                        }
                        pointerUp(t) {
                            this.ctrl.setEventIds(t);
                            try {
                                this.config.pointerCapture && t.target.hasPointerCapture(t.pointerId) && t.target.releasePointerCapture(t.pointerId)
                            } catch (r) {
                                0
                            }
                            const e = this.state,
                                i = this.config;
                            if (!e._active || !e._pointerActive) return;
                            const n = _(t);
                            if (void 0 !== e._pointerId && n !== e._pointerId) return;
                            this.state._pointerActive = !1, this.setActive(), this.compute(t);
                            const [s, o] = e._distance;
                            if (e.tap = s <= i.tapsThreshold && o <= i.tapsThreshold, e.tap && i.filterTaps) e._force = !0;
                            else {
                                const [t, n] = e._delta, [s, o] = e._movement, [r, a] = i.swipe.velocity, [c, h] = i.swipe.distance, u = i.swipe.duration;
                                if (e.elapsedTime < u) {
                                    const i = Math.abs(t / e.timeDelta),
                                        u = Math.abs(n / e.timeDelta);
                                    i > r && Math.abs(s) > c && (e.swipe[0] = Math.sign(t)), u > a && Math.abs(o) > h && (e.swipe[1] = Math.sign(n))
                                }
                            }
                            this.emit()
                        }
                        pointerClick(t) {
                            !this.state.tap && t.detail > 0 && (t.preventDefault(), t.stopPropagation())
                        }
                        setupPointer(t) {
                            const e = this.config,
                                i = e.device;
                            e.pointerLock && t.currentTarget.requestPointerLock(), e.pointerCapture || (this.eventStore.add(this.sharedConfig.window, i, "change", this.pointerMove.bind(this)), this.eventStore.add(this.sharedConfig.window, i, "end", this.pointerUp.bind(this)), this.eventStore.add(this.sharedConfig.window, i, "cancel", this.pointerUp.bind(this)))
                        }
                        pointerClean() {
                            this.config.pointerLock && document.pointerLockElement === this.state.currentTarget && document.exitPointerLock()
                        }
                        preventScroll(t) {
                            this.state._preventScroll && t.cancelable && t.preventDefault()
                        }
                        setupScrollPrevention(t) {
                            this.state._preventScroll = !1,
                                function(t) {
                                    "persist" in t && "function" === typeof t.persist && t.persist()
                                }(t);
                            const e = this.eventStore.add(this.sharedConfig.window, "touch", "change", this.preventScroll.bind(this), {
                                passive: !1
                            });
                            this.eventStore.add(this.sharedConfig.window, "touch", "end", e), this.eventStore.add(this.sharedConfig.window, "touch", "cancel", e), this.timeoutStore.add("startPointerDrag", this.startPointerDrag.bind(this), this.config.preventScrollDelay, t)
                        }
                        setupDelayTrigger(t) {
                            this.state._delayed = !0, this.timeoutStore.add("dragDelay", () => {
                                this.state._step = [0, 0], this.startPointerDrag(t)
                            }, this.config.delay)
                        }
                        keyDown(t) {
                            const e = C[t.key];
                            if (e) {
                                const i = this.state,
                                    s = t.shiftKey ? 10 : t.altKey ? .1 : 1;
                                this.start(t), i._delta = e(this.config.keyboardDisplacement, s), i._keyboardActive = !0, n.addTo(i._movement, i._delta), this.compute(t), this.emit()
                            }
                        }
                        keyUp(t) {
                            t.key in C && (this.state._keyboardActive = !1, this.setActive(), this.compute(t), this.emit())
                        }
                        bind(t) {
                            const e = this.config.device;
                            t(e, "start", this.pointerDown.bind(this)), this.config.pointerCapture && (t(e, "change", this.pointerMove.bind(this)), t(e, "end", this.pointerUp.bind(this)), t(e, "cancel", this.pointerUp.bind(this)), t("lostPointerCapture", "", this.pointerUp.bind(this))), this.config.keys && (t("key", "down", this.keyDown.bind(this)), t("key", "up", this.keyUp.bind(this))), this.config.filterTaps && t("click", "", this.pointerClick.bind(this), {
                                capture: !0,
                                passive: !1
                            })
                        }
                    },
                    resolver: L
                },
                Y = {
                    key: "wheel",
                    engine: class extends A {
                        constructor(...t) {
                            super(...t), a(this, "ingKey", "wheeling")
                        }
                        wheel(t) {
                            this.state._active || this.start(t), this.wheelChange(t), this.timeoutStore.add("wheelEnd", this.wheelEnd.bind(this))
                        }
                        wheelChange(t) {
                            const e = this.state;
                            e._delta = k(t), n.addTo(e._movement, e._delta), V(e), this.compute(t), this.emit()
                        }
                        wheelEnd() {
                            this.state._active && (this.state._active = !1, this.compute(), this.emit())
                        }
                        bind(t) {
                            t("wheel", "", this.wheel.bind(this))
                        }
                    },
                    resolver: U
                };
            var q = i(67294);

            function G(t, e) {
                if (null == t) return {};
                var i, n, s = function(t, e) {
                    if (null == t) return {};
                    var i, n, s = {},
                        o = Object.keys(t);
                    for (n = 0; n < o.length; n++) i = o[n], e.indexOf(i) >= 0 || (s[i] = t[i]);
                    return s
                }(t, e);
                if (Object.getOwnPropertySymbols) {
                    var o = Object.getOwnPropertySymbols(t);
                    for (n = 0; n < o.length; n++) i = o[n], e.indexOf(i) >= 0 || Object.prototype.propertyIsEnumerable.call(t, i) && (s[i] = t[i])
                }
                return s
            }
            const N = {
                    target(t) {
                        if (t) return () => "current" in t ? t.current : t
                    },
                    enabled: (t = !0) => t,
                    window: (t = (j.isBrowser ? window : void 0)) => t,
                    eventOptions: ({
                        passive: t = !0,
                        capture: e = !1
                    } = {}) => ({
                        passive: t,
                        capture: e
                    }),
                    transform: t => t
                },
                W = ["target", "eventOptions", "window", "enabled", "transform"];

            function F(t = {}, e) {
                const i = {};
                for (const [n, s] of Object.entries(e)) switch (typeof s) {
                    case "function":
                        i[n] = s.call(i, t[n], n, t);
                        break;
                    case "object":
                        i[n] = F(t[n], s);
                        break;
                    case "boolean":
                        s && (i[n] = t[n])
                }
                return i
            }
            class J {
                constructor(t, e) {
                    a(this, "_listeners", new Set), this._ctrl = t, this._gestureKey = e
                }
                add(t, e, i, n, s) {
                    const o = this._listeners,
                        r = function(t, e = "") {
                            const i = u[t];
                            return t + (i && i[e] || e)
                        }(e, i),
                        a = h(h({}, this._gestureKey ? this._ctrl.config[this._gestureKey].eventOptions : {}), s);
                    t.addEventListener(r, n, a);
                    const c = () => {
                        t.removeEventListener(r, n, a), o.delete(c)
                    };
                    return o.add(c), c
                }
                clean() {
                    this._listeners.forEach(t => t()), this._listeners.clear()
                }
            }
            class Q {
                constructor() {
                    a(this, "_timeouts", new Map)
                }
                add(t, e, i = 140, ...n) {
                    this.remove(t), this._timeouts.set(t, window.setTimeout(e, i, ...n))
                }
                remove(t) {
                    const e = this._timeouts.get(t);
                    e && window.clearTimeout(e)
                }
                clean() {
                    this._timeouts.forEach(t => {
                        window.clearTimeout(t)
                    }), this._timeouts.clear()
                }
            }
            class Z {
                constructor(t) {
                    a(this, "gestures", new Set), a(this, "_targetEventStore", new J(this)), a(this, "gestureEventStores", {}), a(this, "gestureTimeoutStores", {}), a(this, "handlers", {}), a(this, "config", {}), a(this, "pointerIds", new Set), a(this, "touchIds", new Set), a(this, "state", {
                            shared: {
                                shiftKey: !1,
                                metaKey: !1,
                                ctrlKey: !1,
                                altKey: !1
                            }
                        }),
                        function(t, e) {
                            e.drag && $(t, "drag");
                            e.wheel && $(t, "wheel");
                            e.scroll && $(t, "scroll");
                            e.move && $(t, "move");
                            e.pinch && $(t, "pinch");
                            e.hover && $(t, "hover")
                        }(this, t)
                }
                setEventIds(t) {
                    return m(t) ? (this.touchIds = new Set(y(t)), this.touchIds) : "pointerId" in t ? ("pointerup" === t.type || "pointercancel" === t.type ? this.pointerIds.delete(t.pointerId) : "pointerdown" === t.type && this.pointerIds.add(t.pointerId), this.pointerIds) : void 0
                }
                applyHandlers(t, e) {
                    this.handlers = t, this.nativeHandlers = e
                }
                applyConfig(t, e) {
                    this.config = function(t, e, i = {}) {
                        const n = t,
                            {
                                target: s,
                                eventOptions: o,
                                window: r,
                                enabled: a,
                                transform: c
                            } = n,
                            u = G(n, W);
                        if (i.shared = F({
                                target: s,
                                eventOptions: o,
                                window: r,
                                enabled: a,
                                transform: c
                            }, N), e) {
                            const t = z.get(e);
                            i[e] = F(h({
                                shared: i.shared
                            }, u), t)
                        } else
                            for (const l in u) {
                                const t = z.get(l);
                                t && (i[l] = F(h({
                                    shared: i.shared
                                }, u[l]), t))
                            }
                        return i
                    }(t, e, this.config)
                }
                clean() {
                    this._targetEventStore.clean();
                    for (const t of this.gestures) this.gestureEventStores[t].clean(), this.gestureTimeoutStores[t].clean()
                }
                effect() {
                    return this.config.shared.target && this.bind(), () => this._targetEventStore.clean()
                }
                bind(...t) {
                    const e = this.config.shared,
                        i = {};
                    let n;
                    if (!e.target || (n = e.target(), n)) {
                        if (e.enabled) {
                            for (const e of this.gestures) {
                                const s = this.config[e],
                                    o = tt(i, s.eventOptions, !!n);
                                if (s.enabled) {
                                    new(H.get(e))(this, t, e).bind(o)
                                }
                            }
                            const s = tt(i, e.eventOptions, !!n);
                            for (const e in this.nativeHandlers) s(e, "", i => this.nativeHandlers[e](h(h({}, this.state.shared), {}, {
                                event: i,
                                args: t
                            })), void 0, !0)
                        }
                        for (const t in i) i[t] = x(...i[t]);
                        if (!n) return i;
                        for (const t in i) {
                            const {
                                device: e,
                                capture: s,
                                passive: o
                            } = v(t);
                            this._targetEventStore.add(n, e, "", i[t], {
                                capture: s,
                                passive: o
                            })
                        }
                    }
                }
            }

            function $(t, e) {
                t.gestures.add(e), t.gestureEventStores[e] = new J(t, e), t.gestureTimeoutStores[e] = new Q
            }
            const tt = (t, e, i) => (n, s, o, r = {}, a = !1) => {
                var c, h;
                const u = null !== (c = r.capture) && void 0 !== c ? c : e.capture,
                    l = null !== (h = r.passive) && void 0 !== h ? h : e.passive;
                let d = a ? n : p(n, s, u);
                i && l && (d += "Passive"), t[d] = t[d] || [], t[d].push(o)
            };

            function et(t, e = {}, i, n) {
                const s = q.useMemo(() => new Z(t), []);
                if (s.applyHandlers(t, n), s.applyConfig(e, i), q.useEffect(s.effect.bind(s)), q.useEffect(() => s.clean.bind(s), []), void 0 === e.target) return s.bind.bind(s)
            }

            function it(t, e) {
                return R(X), et({
                    drag: t
                }, e || {}, "drag")
            }

            function nt(t, e) {
                return R(Y), et({
                    wheel: t
                }, e || {}, "wheel")
            }
        }
    }
]);