(self.webpackChunkclient = self.webpackChunkclient || []).push([
    [489], {
        77719: (e, n, l) => {
            "use strict";
            l.r(n), l.d(n, {
                default: () => r
            });
            var o = l(67294),
                a = l(3021),
                t = l(97184),
                c = l(9073);
            o.createElement;
            const r = [{
                path: "/orders/:orderId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(6644)]).then(l.bind(l, 15614))
                    },
                    Placeholder: null,
                    chunkName: "order_details_page_line"
                })
            }, {
                path: "/login*",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(7729)]).then(l.bind(l, 64392))
                    },
                    Placeholder: null,
                    chunkName: "login_page_line"
                })
            }, {
                path: "/redirector*",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(8612), l.e(975)]).then(l.bind(l, 58848))
                    },
                    Placeholder: null,
                    chunkName: "redirector_page_common"
                })
            }, {
                path: "/orders",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(6949)]).then(l.bind(l, 38658))
                    },
                    Placeholder: null,
                    chunkName: "orders_page_line"
                }),
                requireAuth: !0
            }, {
                path: "/checkout/:checkoutType/:checkoutstep",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(3455)]).then(l.bind(l, 31585))
                    },
                    Placeholder: null,
                    chunkName: "checkout_page_line"
                })
            }, {
                path: "/exchange-checkout",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(3455)]).then(l.bind(l, 4363))
                    },
                    Placeholder: null,
                    chunkName: "exchange_checkout_page_line"
                })
            }, {
                path: "/return-exchange/:orderId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(4414)]).then(l.bind(l, 93325))
                    },
                    Placeholder: null,
                    chunkName: "return_exchange_flow_page_line"
                })
            }, {
                path: "/bag",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5146)]).then(l.bind(l, 66213))
                    },
                    Placeholder: null,
                    chunkName: "bag_page_line"
                })
            }, {
                path: "/catalogue/:catalogueId/:skuId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(519), l.e(373)]).then(l.bind(l, 34715))
                    },
                    Placeholder: null,
                    chunkName: "catalogue_page_line"
                })
            }, {
                path: "/:catalogueSlug/catalogue/:catalogueId/:skuId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(519), l.e(373)]).then(l.bind(l, 34715))
                    },
                    Placeholder: null,
                    chunkName: "catalogue_page_line"
                })
            }, {
                path: "/featured/:pageId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 69185))
                    },
                    Placeholder: null,
                    chunkName: "feature_page_line"
                })
            }, {
                path: "/order-payment/:orderId/:action?",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(3455)]).then(l.bind(l, 10153))
                    },
                    Placeholder: null,
                    chunkName: "payment_page_line"
                })
            }, {
                path: "/collection/:collectionId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 17750))
                    },
                    Placeholder: null,
                    chunkName: "collection_page_line"
                })
            }, {
                path: "/:collectionSlug/collection/:collectionId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 17750))
                    },
                    Placeholder: null,
                    chunkName: "collection_page_line"
                })
            }, {
                path: "/",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 11886))
                    },
                    Placeholder: null,
                    chunkName: "home_page_line"
                })
            }, {
                path: "/search",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(2965)]).then(l.bind(l, 69625))
                    },
                    Placeholder: null,
                    chunkName: "search_page_line"
                })
            }, {
                path: "/privacy-policy",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(519), l.e(373)]).then(l.bind(l, 9908))
                    },
                    Placeholder: null,
                    chunkName: "privacy_policy_line"
                })
            }, {
                path: "/return-policy",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(519), l.e(373)]).then(l.bind(l, 9908))
                    },
                    Placeholder: null,
                    chunkName: "return_policy_line"
                })
            }, {
                path: "/terms-and-conditions",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(519), l.e(373)]).then(l.bind(l, 9908))
                    },
                    Placeholder: null,
                    chunkName: "terms_and_conditions_line"
                })
            }, {
                path: "/about-us",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(519), l.e(373)]).then(l.bind(l, 9908))
                    },
                    Placeholder: null,
                    chunkName: "about_us_line"
                })
            }, {
                path: "/shipping-policy",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(519), l.e(373)]).then(l.bind(l, 9908))
                    },
                    Placeholder: null,
                    chunkName: "shipping_policy_line"
                })
            }, {
                path: "/testimonials",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 4854))
                    },
                    Placeholder: null,
                    chunkName: "testimonial_page_line"
                })
            }, {
                path: "/new-coupon/:couponCode",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 55255))
                    },
                    Placeholder: null,
                    chunkName: "new_coupon_line"
                })
            }, {
                path: "/product-reviews/:catalogueId/:skuId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 10049))
                    },
                    Placeholder: null,
                    chunkName: "reviews_and_ratings_line"
                })
            }, {
                path: "/similar-products/:catalogueId/:skuId",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 88499))
                    },
                    Placeholder: null,
                    chunkName: "similar_products_line"
                })
            }, {
                path: "/recent-best-sellers",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(5779), l.e(7829)]).then(l.bind(l, 19903))
                    },
                    Placeholder: null,
                    chunkName: "recent_best_sellers_line"
                })
            }, {
                path: "/online-order-payment/:orderId/:action?",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return Promise.all([l.e(3680), l.e(9811), l.e(8612), l.e(1294), l.e(29), l.e(3455)]).then(l.bind(l, 43014))
                    },
                    Placeholder: null,
                    chunkName: "payment_status_page_line"
                })
            }, {
                path: "/maintenance",
                exact: !0,
                component: (0, t.B)({
                    loader: function() {
                        return l.e(6725).then(l.bind(l, 238))
                    },
                    Placeholder: null,
                    chunkName: "maintenance_page_line"
                })
            }, {
                path: "**",
                component: function(e) {
                    return (0, c.tZ)(a.Z, {
                        redirectTo: "/"
                    })
                }
            }]
        }
    }
]);