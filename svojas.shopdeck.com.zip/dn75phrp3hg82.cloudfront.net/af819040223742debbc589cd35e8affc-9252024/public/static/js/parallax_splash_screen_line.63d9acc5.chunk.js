(self.webpackChunkclient = self.webpackChunkclient || []).push([
    [5862], {
        17201: (e, t, i) => {
            "use strict";
            i.d(t, {
                Z: () => a
            });
            var n = i(22122),
                o = i(81253),
                r = i(67294),
                s = i(9073),
                l = ["width", "height"];
            r.createElement;
            const a = function(e) {
                var t = e.width,
                    i = void 0 === t ? "24" : t,
                    r = e.height,
                    a = void 0 === r ? "32" : r,
                    c = (0, o.Z)(e, l);
                return (0, s.tZ)("svg", (0, n.Z)({
                    width: i,
                    height: a
                }, c, {
                    viewBox: "0 0 24 24",
                    fill: "none",
                    xmlns: "http://www.w3.org/2000/svg"
                }), (0, s.tZ)("path", {
                    d: "M8.12 22.71 12 18.83l3.88 3.88a.996.996 0 1 0 1.41-1.41l-4.59-4.59a.996.996 0 0 0-1.41 0L6.7 21.3a.996.996 0 0 0 0 1.41c.39.38 1.03.39 1.42 0zM8.12 14.71 12 10.83l3.88 3.88a.996.996 0 1 0 1.41-1.41L12.7 8.71a.996.996 0 0 0-1.41 0L6.7 13.3a.996.996 0 0 0 0 1.41c.39.38 1.03.39 1.42 0z",
                    fill: "#fff"
                }))
            }
        },
        85566: (e, t, i) => {
            "use strict";
            i.r(t), i.d(t, {
                default: () => P
            });
            var n, o = i(22122),
                r = i(34699),
                s = i(81253),
                l = i(32465),
                a = i(67294),
                c = i(9073),
                u = i(28216),
                d = i(28197),
                g = i(281),
                f = i(73283),
                h = i(22464),
                v = i(17201),
                w = i(67190),
                m = i(64435),
                p = i(35219),
                Z = i(5534),
                x = i(72005),
                b = i(9275),
                S = i(78090),
                y = ["logoUrl", "swipeUpScreenConfig", "uiSettings", "isParallexVisible", "viewAs", "showCTA"];
            a.createElement;
            var _ = (0, x.sl)("splash", "general"),
                k = (0, c.F4)(n || (n = (0, l.Z)(["\n  0%, 100% {\n    transform: translateY(0);\n  }\n  50% {\n    transform: translateY(-10px);\n  }\n"]))),
                L = {
                    startShoppingArrow: (0, c.iv)("margin-bottom:24px;animation:", k, " 1.2s linear infinite;", "")
                },
                C = !1,
                U = {
                    name: "ugur8o",
                    styles: "text-align:center;width:100%;>div{margin:0 auto;}"
                },
                A = {
                    name: "zw7em0",
                    styles: "bottom:0;padding:12px;padding-bottom:48px;position:absolute;width:100%"
                },
                E = {
                    name: "o8vd7w",
                    styles: "height:100%;max-width:1200px;margin:0 auto;position:relative"
                },
                z = a.memo((function(e) {
                    e.logoUrl;
                    var t = e.swipeUpScreenConfig,
                        i = e.uiSettings,
                        n = void 0 === i ? {} : i,
                        l = e.isParallexVisible,
                        u = e.viewAs,
                        p = void 0 === u ? _.general : u,
                        Z = e.showCTA,
                        k = void 0 === Z || Z,
                        z = (0, s.Z)(e, y),
                        P = a.useState(n.show_swipe_up_screen && l),
                        I = (0, r.Z)(P, 2),
                        V = I[0],
                        M = I[1],
                        T = t.title,
                        Y = t.title_alignment,
                        q = t.title_color,
                        F = t.show_title,
                        G = t.show_logo,
                        R = t.logo_alignment,
                        W = t.cover_url,
                        j = a.useState(),
                        B = (0, r.Z)(j, 2),
                        $ = B[0],
                        D = B[1],
                        H = (0, a.useState)(0),
                        J = H[0],
                        K = H[1],
                        N = a.useRef(null),
                        O = (0, S.m)();
                    a.useLayoutEffect((function() {
                        var e = !C && (n.show_swipe_up_screen && l);
                        M(p === _.general || e)
                    }), [l, n, p]), a.useLayoutEffect((function() {
                        if (p !== _.general && V) {
                            C || (C = !0);
                            var e = (0, x._W)(W);
                            b.U.loadImage(e).then((function() {
                                return D(e)
                            }))
                        }
                    }), []);
                    var Q = a.useCallback((function() {
                        K(100)
                    }), []);
                    (0, a.useEffect)((function() {
                        if (p !== _.general) {
                            if (V) {
                                var e = function(e) {
                                    document.body.classList.remove("overflow-hidden")
                                };
                                return document.body.classList.add("overflow-hidden"), N.current && N.current.querySelector("section").addEventListener("transitionend", e),
                                    function() {
                                        N.current && N.current.querySelector("section").removeEventListener("transitionend", e), document.body.classList.remove("overflow-hidden")
                                    }
                            }
                            document.body.classList.remove("overflow-hidden")
                        }
                    }), [V]);
                    var X, ee = a.useCallback((function(e) {
                            -1 === e.direction[1] && 100 !== J && K(100)
                        }), []),
                        te = a.useCallback((function(e) {
                            1 === e.direction[1] && 100 !== J && K(100)
                        }), []),
                        ie = (0, d.c0)(ee),
                        ne = (0, d.rv)(te),
                        oe = O ? ie : ne,
                        re = ("left" === (X = R) ? "start" : "right" === X ? "end" : X) || "left";
                    return V ? (0, c.tZ)("div", (0, o.Z)({
                        ref: N
                    }, oe()), (0, c.tZ)(w.Z, (0, o.Z)({
                        RenderAs: "section",
                        xs: (0, c.iv)($ && 'background-image: url("'.concat($, '")'), ";height:100vh;background-position:center;background-repeat:no-repeat;background-size:cover;z-index:10;position:fixed;width:100%;transition:all .5s linear;transform:translateY(", -1 * J, "vh);", "")
                    }, z), (0, c.tZ)(w.Z, {
                        xs: E
                    }, (0, c.tZ)(w.Z, {
                        xs: A
                    }, (0, c.tZ)(w.Z, {
                        css: (0, c.iv)("display:flex;flex-direction:column;align-items:", re, ";", "")
                    }, G && (0, c.tZ)(m.Z, {
                        width: "fit",
                        height: 120,
                        fontStyleGuide: "title1",
                        showLogoImage: !0
                    })), F && (0, c.tZ)(g.ZP, {
                        mt: "xlg",
                        mb: "xxlg",
                        fontStyleGuide: "title1",
                        align: Y,
                        css: (0, c.iv)("color:", q, ";", "")
                    }, T), (0, c.tZ)(w.Z, {
                        xs: U
                    }, k && (0, c.tZ)(h.Z, {
                        xs: 24,
                        xl: 8,
                        alignItems: "center"
                    }, (0, c.tZ)(v.Z, {
                        css: L.startShoppingArrow
                    }), (0, c.tZ)(f.ZP, {
                        onClick: Q,
                        isFullWidth: !0,
                        size: "large",
                        type: "primary"
                    }, "Start shopping"))))))) : null
                }));
            const P = (0, u.$j)((function(e) {
                return {
                    logoUrl: p.wl.logoUrl(e),
                    isParallexVisible: Z.wl.isParallexVisible(e),
                    swipeUpScreenConfig: p.wl.swipeUpScreen(e),
                    uiSettings: p.wl.uiSettings(e)
                }
            }))(z)
        },
        78090: (e, t, i) => {
            "use strict";
            i.d(t, {
                m: () => o
            });
            var n = i(23076),
                o = function() {
                    var e = n.U2("device");
                    return e && (e.isMobile || e.isIphone || e.isTablet)
                }
        }
    }
]);