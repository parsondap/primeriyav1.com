(self.webpackChunkclient = self.webpackChunkclient || []).push([
    [5626], {
        97184: (e, t, r) => {
            "use strict";
            r.d(t, {
                B: () => o
            });
            var n = r(23245),
                i = r(67294);

            function o(e) {
                var t = e.loader,
                    r = e.Placeholder,
                    o = e.chunkName,
                    a = null;
                return function(e) {
                    function s() {
                        var t;
                        return (t = e.apply(this, arguments) || this).state = {
                            Component: a
                        }, t.updateState = function() {
                            t.state.Component !== a && t.setState({
                                Component: a
                            })
                        }, t
                    }(0, n.UL)(s, e), s.load = function() {
                        return t().then((function(e) {
                            a = e.default || e
                        }))
                    }, s.getChunkName = function() {
                        return o
                    }, s.getInitialProps = function(e) {
                        if (null !== a) return a.getInitialProps ? a.getInitialProps(e) : Promise.resolve(null)
                    };
                    var l = s.prototype;
                    return l.componentDidMount = function() {
                        s.load().then(this.updateState)
                    }, l.render = function() {
                        var e = this.state.Component;
                        return e ? (0, i.createElement)(e, Object.assign({}, this.props)) : r ? (0, i.createElement)(r, Object.assign({}, this.props)) : null
                    }, s
                }(i.Component)
            }
        },
        73283: (e, t, r) => {
            "use strict";
            r.d(t, {
                ZP: () => P
            });
            var n, i, o, a = r(22122),
                s = r(81253),
                l = r(96156),
                d = r(67294),
                c = r(9073),
                p = r(20509),
                u = r(72005),
                g = r(90297),
                h = r(281),
                f = ["shape", "type", "size", "disabled", "children", "className", "isFullWidth", "isTransparent", "to", "linkStyle", "onClick", "domType", "badgeCount", "dataSdEvent"];
            d.createElement;
            var v = (0, u.sl)("primary", "primaryTransparent", "secondary", "icon", "iconOnly", "iconBadge", "danger", "accent", "bumper"),
                y = (0, u.sl)("tiny", "small", "medium", "large", "xl"),
                b = (0, u.sl)("normal", "circle", "pill"),
                m = ((0, u.sl)("ghost", "translucent", "opaque", "transparent"), {
                    name: "2wjmro",
                    styles: "position:relative;appearance:none;overflow:hidden;outline:0px;&:hover,&:active,&:focus{outline:0px;}border-width:1px;border-style:solid;cursor:pointer"
                }),
                _ = {
                    button: (0, c.iv)(m, ";font-family:var(--body),sans-serif;font-weight:bold;", ""),
                    container: {
                        name: "2f3j1g",
                        styles: "display:flex;justify-content:center;align-items:center;font-size:inherit;&>svg:first-of-type,&>img:first-of-type{margin-right:12px;}"
                    },
                    fullWidth: {
                        name: "1d3w5wq",
                        styles: "width:100%"
                    },
                    link: {
                        name: "5ppxz5",
                        styles: "text-decoration:none;display:block"
                    },
                    badgeCount: (0, c.iv)("position:absolute;border-radius:10px;min-width:20px;min-height:20px;padding:2px 6px;transform:translate(50%,-50%);background-color:", g.Z.grey1, ";color:white;", "")
                },
                x = (n = {}, (0, l.Z)(n, y.small, {
                    name: "17jragu",
                    styles: "padding:4px 14px;font-size:14px;line-height:20px;text-transform:uppercase"
                }), (0, l.Z)(n, y.medium, {
                    name: "1yqvgxq",
                    styles: "padding:10px;font-size:14px;line-height:20px;text-transform:uppercase"
                }), (0, l.Z)(n, y.large, {
                    name: "1yd6dr0",
                    styles: "padding:12px;font-size:14px;line-height:20px;text-transform:uppercase"
                }), (0, l.Z)(n, y.xl, {
                    name: "76ze8n",
                    styles: "padding:15px 40px;font-size:16px;line-height:24px;text-transform:uppercase;@media(max-width: 1200px){padding:4px 14px;font-size:14px;line-height:20px;}"
                }), n),
                w = (i = {}, (0, l.Z)(i, b.sharp, {
                    name: "12fr4ox",
                    styles: "border-radius:0px"
                }), (0, l.Z)(i, b.normal, {
                    name: "1u8hqvf",
                    styles: "border-radius:4px"
                }), (0, l.Z)(i, b.pill, {
                    name: "4pt2un",
                    styles: "border-radius:12px"
                }), (0, l.Z)(i, b.circle, {
                    name: "hetn6c",
                    styles: "border-radius:50%;padding:12px;&>svg,&>img{margin:0px;}"
                }), i),
                E = (o = {}, (0, l.Z)(o, v.primary, (0, c.iv)("background-color:", g.Z.grey, ";color:", g.Z.white1, ";border:1px solid transparent;", "")), (0, l.Z)(o, v.primaryTransparent, (0, c.iv)("background-color:transparent;color:", g.Z.white1, ";border:1px solid ", g.Z.white1, ";transition:.5s ease;&:disabled{pointer-events:none;}&:hover{background-color:", g.Z.grey, ";border:1px solid ", g.Z.grey, ";}", "")), (0, l.Z)(o, v.secondary, (0, c.iv)("background-color:transparent;color:", g.Z.grey, ";border:1px solid ", g.Z.grey4, ";&:disabled{pointer-events:none;}&:hover{background-color:", g.Z.grey, ";color:", g.Z.white1, ";transition:.5s ease;}&:hover{>div p{color:", g.Z.white1, ";transition:.5s ease;}}", "")), (0, l.Z)(o, v.icon, (0, c.iv)("background-color:", g.Z.white1, ";color:", g.Z.grey1, ";border:1px solid ", g.Z.grey4, ";", "")), (0, l.Z)(o, v.iconOnly, {
                    name: "1sv9fp8",
                    styles: "background-color:transparent;color:transparent;border:none;padding:0!important"
                }), (0, l.Z)(o, v.iconBadge, {
                    name: "nwj7vc",
                    styles: "background-color:transparent;color:transparent;border:none;padding:0!important;overflow:visible;svg,img{margin:0px;}"
                }), (0, l.Z)(o, v.danger, (0, c.iv)("background-color:transparent;color:", g.Z.brand, ";border:1px solid ", g.Z.brand, ";", "")), (0, l.Z)(o, v.accent, (0, c.iv)("background-color:", g.Z.grey4, ";color:", g.Z.grey, ";border:1px solid ", g.Z.grey4, ";", "")), (0, l.Z)(o, v.bumper, (0, c.iv)("color:", g.Z.white1, ";border:none;", "")), o),
                Z = "sharp",
                C = "primary",
                k = "large",
                I = {
                    name: "1d3w5wq",
                    styles: "width:100%"
                },
                T = (0, c.iv)("background-color:", g.Z.grey2, ";color:", g.Z.white1, ";border-color:none;", "");
            const P = d.forwardRef((function(e, t) {
                var r = e.shape,
                    n = void 0 === r ? Z : r,
                    i = e.type,
                    o = void 0 === i ? C : i,
                    l = e.size,
                    d = void 0 === l ? k : l,
                    u = e.disabled,
                    g = e.children,
                    y = e.className,
                    b = e.isFullWidth,
                    m = (e.isTransparent, e.to),
                    P = e.linkStyle,
                    O = e.onClick,
                    N = e.domType,
                    D = e.badgeCount,
                    A = e.dataSdEvent,
                    S = (0, s.Z)(e, f),
                    R = (0, c.tZ)("button", (0, a.Z)({
                        "data-sd-event": A,
                        disabled: u,
                        ref: t,
                        css: (0, c.iv)(_.button, " ", E[o], " ", x[d], " ", w[n], " ", b ? I : "", " ", u && T, ";", ""),
                        className: y,
                        onClick: u ? null : O,
                        type: N
                    }, S), (0, c.tZ)("div", {
                        css: _.container
                    }, g, o === v.iconBadge && D ? (0, c.tZ)("div", {
                        css: _.badgeCount
                    }, (0, c.tZ)(h.ZP, {
                        RenderAs: "p",
                        fontStyleGuide: "body3",
                        color: "white1",
                        align: "center"
                    }, D)) : null));
                return m && !u ? (0, c.tZ)(p.Z, {
                    to: m,
                    css: [_.link, P, "", ""]
                }, R) : R
            }))
        },
        15471: (e, t, r) => {
            "use strict";
            r.d(t, {
                a: () => n
            });
            var n = "https://d1311wbk6unapo.cloudfront.net/NushopWebsiteAsset/image_placeholder_2.png"
        },
        90349: (e, t, r) => {
            "use strict";
            r.d(t, {
                Z: () => d
            });
            var n = r(6610),
                i = r(5991),
                o = r(10379),
                a = r(90738),
                s = r(67294),
                l = r(9073);
            s.createElement;
            const d = function(e) {
                return function(t) {
                    (0, o.Z)(s, t);
                    var r = (0, a.Z)(s);

                    function s() {
                        return (0, n.Z)(this, s), r.apply(this, arguments)
                    }
                    return (0, i.Z)(s, [{
                        key: "render",
                        value: function() {
                            return (0, l.tZ)(e, this.props)
                        }
                    }]), s
                }(s.Component)
            }
        },
        3021: (e, t, r) => {
            "use strict";
            r.d(t, {
                Z: () => b
            });
            var n = r(81253),
                i = r(67294),
                o = r(97980),
                a = r(22464),
                s = r(73283),
                l = r(281),
                d = r(32547),
                c = r(67190),
                p = r(9073);
            i.createElement;
            var u = {
                    wrapperInLg: {
                        name: "vbyx27",
                        styles: "position:relative;height:70vh;width:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:12px"
                    },
                    wrapperInXs: {
                        name: "1jidyql",
                        styles: "position:relative;height:80vh;width:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:12px"
                    }
                },
                g = {
                    name: "1w35t6o",
                    styles: "position:relative;width:100%;padding:12px"
                },
                h = {
                    name: "1ev49ri",
                    styles: "position:absolute;width:100%;padding:12px;bottom:0"
                };
            const f = function(e) {
                var t = e.redirectTo,
                    r = void 0 === t ? "/" : t;
                return (0, p.tZ)(i.Fragment, null, (0, p.tZ)(c.Z, {
                    lg: u.wrapperInLg,
                    xs: u.wrapperInXs
                }, (0, p.tZ)(o.ZP, {
                    align: "center",
                    justify: "center"
                }, (0, p.tZ)(a.Z, {
                    lg: 24,
                    md: 24,
                    sm: 24,
                    xs: 24
                }, (0, p.tZ)(d.At, {
                    aspectRatio: .5,
                    src: "https://d1311wbk6unapo.cloudfront.net/ResellerGroup/tr:w-600,f_auto,fo-auto/saheli_group_TEGXDMNNL8_2021-12-16_1.png"
                }), (0, p.tZ)(l.ZP, {
                    RenderAs: "h3",
                    fontStyleGuide: "heading1",
                    family: "inter",
                    color: "grey1",
                    align: "center"
                }, "The page you\u2019re looking for, does not exist!")), (0, p.tZ)(c.Z, {
                    xs: h,
                    lg: g
                }, (0, p.tZ)(a.Z, {
                    lg: 24,
                    md: 24,
                    sm: 24,
                    xs: 24
                }, (0, p.tZ)(s.ZP, {
                    isFullWidth: !0,
                    to: r
                }, "Go Back"))))))
            };
            var v = r(90349),
                y = ["redirectTo"];
            i.createElement;
            const b = (0, v.Z)((function(e) {
                var t = e.redirectTo,
                    r = void 0 === t ? "/" : t;
                (0, n.Z)(e, y);
                return (0, p.tZ)(i.Fragment, null, (0, p.tZ)(f, {
                    redirectTo: r
                }))
            }))
        },
        9275: (e, t, r) => {
            "use strict";
            r.d(t, {
                U: () => i
            });
            var n = r(41497),
                i = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = {};
                    return {
                        isImageLoaded: function(t) {
                            return !!(e[t] & n.BQ.success)
                        },
                        loadImage: function(r) {
                            if (!r) return Promise.reject("No src available");
                            if (e[r] & n.BQ.success) return Promise.resolve(r);
                            if (t[r]) return t[r];
                            var i = new Promise((function(i, o) {
                                var a = new Image;
                                a.onload = function() {
                                    e[r] = n.BQ.success, t[r] = null, a.onload = null, a.onerror = null, i(r)
                                }, a.onerror = function(e) {
                                    a.onload = null, a.onerror = null, t[r] = null, o(e)
                                }, a.src = r
                            }));
                            return t[r] = i, i
                        }
                    }
                }({})
        },
        41497: (e, t, r) => {
            "use strict";
            r.d(t, {
                BQ: () => i,
                yY: () => o,
                FZ: () => a,
                oL: () => s,
                GE: () => l,
                Wg: () => d,
                DF: () => c,
                sO: () => p,
                oI: () => u,
                Iw: () => g,
                dq: () => h,
                gi: () => f
            });
            var n = r(72005),
                i = {
                    none: 0,
                    waiting: 1,
                    success: 2,
                    failure: 4
                },
                o = ((0, n.sl)("android", "web"), (0, n.sl)("gujarati"), {
                    PAYMENT_INITIATED: "__wm_payment_initiated",
                    ORDER_STATUS: "__ns_order_status",
                    SELECTED_ONLINE_PAYMENT_METHOD: "__ns_selected_online_payment_method",
                    PRESELECTED_PAYMENT_GATEWAY: "__ns_preselected_online_payment_gateway"
                }),
                a = "__ns_recently_viewed",
                s = ["created", "printed", "packed", "dispatched", "delivered", "initiated", "paused", "enqueued"],
                l = {
                    requestContact: "requestContact",
                    requestAddress: "requestAddress",
                    requestOTP: "requestOTP",
                    orderPreview: "orderPreview",
                    orderSuccess: "orderSuccess",
                    orderFailure: "orderFailure",
                    orderPreviewPayment: "orderPreviewPayment"
                },
                d = {
                    none: "none",
                    sizeSelectorModal: "sizeSelectorModal",
                    readyForExchangeModal: "readyForExchangeModal",
                    sizeChart: "sizeChart",
                    customisationModal: "customisationModal",
                    initiateCheckout: "initiateCheckout"
                },
                c = {
                    PAUSED: "paused",
                    INITIATED: "initiated",
                    ENQUEUED: "enqueued",
                    CREATED: "created",
                    PRINTED: "printed",
                    PACKED: "packed",
                    DISPATCHED: "dispatched",
                    DELIVERED: "delivered",
                    RTO_INITIATED: "rto_initiated",
                    RTO_DELIVERED: "rto_delivered",
                    RTO_ACKNOWLEDGED: "rto_acknowledged",
                    CANCELLED: "cancelled",
                    CANCEL_INITIATED: "cancel_initiated",
                    LOST: "lost",
                    EXCHANGE_PICKUP: "exchange_pickup",
                    EXCHANGE_DISPATCHED: "exhange_dispatched",
                    EXCHANGE_DELIVERED: "exchange_delivered",
                    INVALID: "invalid"
                },
                p = ((0, n.sl)("ONLINE_PAYMENT_MODE_POPUP_DISPLAYED"), (0, n.sl)("ORDER_PREVIEW_TO_ONLINE_PAGE_STEPS_COUNT", "SELECTED_COUPON_CODE", "ORDER_ID_COD")),
                u = {
                    RECTANGLE: 1.4,
                    SQUARE: 1
                },
                g = (0, n.sl)("single", "multiple"),
                h = (0, n.sl)("default", "wizard"),
                f = 2e4
        },
        90297: (e, t, r) => {
            "use strict";
            r.d(t, {
                Z: () => n
            });
            const n = {
                brand: "#f44336",
                error: "#f44336",
                warning: "#f7b500",
                orange: "#f2994a",
                grey: "var(--grey)",
                grey1: "var(--grey1)",
                grey2: "var(--grey2)",
                grey3: "var(--grey3)",
                grey4: "var(--grey4)",
                grey5: "var(--grey5)",
                white1: "var(--white1)",
                white2: "var(--white2)",
                white3: "var(--white3)",
                white4: "var(--white4)",
                green1: "#27ae60",
                green2: "rgba(0, 201, 75, 0.08)",
                yellow: "#f7d01e",
                red: "#ee5858",
                light_blue_transparent: "rgb(235, 247, 255)",
                black: "rgb(0, 0, 0)",
                text_brand: "#f44336",
                text_error: "#f44336",
                text_warning: "#f7b500",
                text_grey: "rgba(0, 0, 0, 1)",
                text_grey1: "rgba(0, 0, 0, 0.7)",
                text_grey2: "rgba(0, 0, 0, 0.4)",
                text_grey3: "rgba(0, 0, 0, 0.25)",
                text_grey4: "rgba(0, 0, 0, 0.1)",
                text_grey5: "rgba(0, 0, 0, 0.03)",
                text_white1: "var(--white1)",
                text_white2: "var(--white2)",
                text_white3: "var(--white3)",
                text_white4: "var(--white4)",
                text_green1: "#27ae60",
                text_orange: "#f2994a",
                text_green2: "rgba(0, 201, 75, 0.08)",
                text_black: "rgb(0, 0, 0)",
                red1: "#f44336",
                text_blue1: "#4764cd",
                text_blue2: "#eff2fa",
                blue1: "#4764cd",
                blue2: "#eff2fa"
            }
        },
        70131: (e, t, r) => {
            "use strict";
            r.d(t, {
                df: () => f,
                Wx: () => c
            });
            var n = r(67294);

            function i() {
                return (i = Object.assign || function(e) {
                    for (var t = 1; t < arguments.length; t++) {
                        var r = arguments[t];
                        for (var n in r) Object.prototype.hasOwnProperty.call(r, n) && (e[n] = r[n])
                    }
                    return e
                }).apply(this, arguments)
            }

            function o(e, t) {
                return (o = Object.setPrototypeOf || function(e, t) {
                    return e.__proto__ = t, e
                })(e, t)
            }
            var a = new Map,
                s = new WeakMap,
                l = 0,
                d = void 0;

            function c(e) {
                d = e
            }

            function p(e) {
                return Object.keys(e).sort().filter((function(t) {
                    return void 0 !== e[t]
                })).map((function(t) {
                    return t + "_" + ("root" === t ? (r = e.root) ? (s.has(r) || (l += 1, s.set(r, l.toString())), s.get(r)) : "0" : e[t]);
                    var r
                })).toString()
            }

            function u(e, t, r, n) {
                if (void 0 === r && (r = {}), void 0 === n && (n = d), "undefined" === typeof window.IntersectionObserver && void 0 !== n) {
                    var i = e.getBoundingClientRect();
                    return t(n, {
                            isIntersecting: n,
                            target: e,
                            intersectionRatio: "number" === typeof r.threshold ? r.threshold : 0,
                            time: 0,
                            boundingClientRect: i,
                            intersectionRect: i,
                            rootBounds: i
                        }),
                        function() {}
                }
                var o = function(e) {
                        var t = p(e),
                            r = a.get(t);
                        if (!r) {
                            var n, i = new Map,
                                o = new IntersectionObserver((function(t) {
                                    t.forEach((function(t) {
                                        var r, o = t.isIntersecting && n.some((function(e) {
                                            return t.intersectionRatio >= e
                                        }));
                                        e.trackVisibility && "undefined" === typeof t.isVisible && (t.isVisible = o), null == (r = i.get(t.target)) || r.forEach((function(e) {
                                            e(o, t)
                                        }))
                                    }))
                                }), e);
                            n = o.thresholds || (Array.isArray(e.threshold) ? e.threshold : [e.threshold || 0]), r = {
                                id: t,
                                observer: o,
                                elements: i
                            }, a.set(t, r)
                        }
                        return r
                    }(r),
                    s = o.id,
                    l = o.observer,
                    c = o.elements,
                    u = c.get(e) || [];
                return c.has(e) || c.set(e, u), u.push(t), l.observe(e),
                    function() {
                        u.splice(u.indexOf(t), 1), 0 === u.length && (c.delete(e), l.unobserve(e)), 0 === c.size && (l.disconnect(), a.delete(s))
                    }
            }
            var g = ["children", "as", "triggerOnce", "threshold", "root", "rootMargin", "onChange", "skip", "trackVisibility", "delay", "initialInView", "fallbackInView"];

            function h(e) {
                return "function" !== typeof e.children
            }
            var f = function(e) {
                var t, r;

                function a(t) {
                    var r;
                    return (r = e.call(this, t) || this).node = null, r._unobserveCb = null, r.handleNode = function(e) {
                        r.node && (r.unobserve(), e || r.props.triggerOnce || r.props.skip || r.setState({
                            inView: !!r.props.initialInView,
                            entry: void 0
                        })), r.node = e || null, r.observeNode()
                    }, r.handleChange = function(e, t) {
                        e && r.props.triggerOnce && r.unobserve(), h(r.props) || r.setState({
                            inView: e,
                            entry: t
                        }), r.props.onChange && r.props.onChange(e, t)
                    }, r.state = {
                        inView: !!t.initialInView,
                        entry: void 0
                    }, r
                }
                r = e, (t = a).prototype = Object.create(r.prototype), t.prototype.constructor = t, o(t, r);
                var s = a.prototype;
                return s.componentDidUpdate = function(e) {
                    e.rootMargin === this.props.rootMargin && e.root === this.props.root && e.threshold === this.props.threshold && e.skip === this.props.skip && e.trackVisibility === this.props.trackVisibility && e.delay === this.props.delay || (this.unobserve(), this.observeNode())
                }, s.componentWillUnmount = function() {
                    this.unobserve(), this.node = null
                }, s.observeNode = function() {
                    if (this.node && !this.props.skip) {
                        var e = this.props,
                            t = e.threshold,
                            r = e.root,
                            n = e.rootMargin,
                            i = e.trackVisibility,
                            o = e.delay,
                            a = e.fallbackInView;
                        this._unobserveCb = u(this.node, this.handleChange, {
                            threshold: t,
                            root: r,
                            rootMargin: n,
                            trackVisibility: i,
                            delay: o
                        }, a)
                    }
                }, s.unobserve = function() {
                    this._unobserveCb && (this._unobserveCb(), this._unobserveCb = null)
                }, s.render = function() {
                    if (!h(this.props)) {
                        var e = this.state,
                            t = e.inView,
                            r = e.entry;
                        return this.props.children({
                            inView: t,
                            entry: r,
                            ref: this.handleNode
                        })
                    }
                    var o = this.props,
                        a = o.children,
                        s = o.as,
                        l = function(e, t) {
                            if (null == e) return {};
                            var r, n, i = {},
                                o = Object.keys(e);
                            for (n = 0; n < o.length; n++) r = o[n], t.indexOf(r) >= 0 || (i[r] = e[r]);
                            return i
                        }(o, g);
                    return n.createElement(s || "div", i({
                        ref: this.handleNode
                    }, l), a)
                }, a
            }(n.Component);
            f.displayName = "InView", f.defaultProps = {
                threshold: 0,
                triggerOnce: !1,
                initialInView: !1
            }
        }
    }
]);