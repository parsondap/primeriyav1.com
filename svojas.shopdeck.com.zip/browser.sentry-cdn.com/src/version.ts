export const SDK_NAME = 'sentry.javascript.browser';
export const SDK_VERSION = '5.4.3';
